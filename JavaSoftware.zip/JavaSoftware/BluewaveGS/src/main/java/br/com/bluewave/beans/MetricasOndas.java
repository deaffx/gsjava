package br.com.bluewave.beans;

import java.sql.Timestamp;

public class MetricasOndas {
    private int id;
    private int idEstacao;
    private double alturaOnda;
    private double periodoOnda;
    private Timestamp dataHora;

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEstacao() {
        return idEstacao;
    }

    public void setIdEstacao(int idEstacao) {
        this.idEstacao = idEstacao;
    }

    public double getAlturaOnda() {
        return alturaOnda;
    }

    public void setAlturaOnda(double alturaOnda) {
        this.alturaOnda = alturaOnda;
    }

    public double getPeriodoOnda() {
        return periodoOnda;
    }

    public void setPeriodoOnda(double periodoOnda) {
        this.periodoOnda = periodoOnda;
    }

    public Timestamp getDataHora() {
        return dataHora;
    }

    public void setDataHora(Timestamp dataHora) {
        this.dataHora = dataHora;
    }

    // Construtores
    public MetricasOndas() {}

    public MetricasOndas(int id, int idEstacao, double alturaOnda, double periodoOnda, Timestamp dataHora) {
        this.id = id;
        this.idEstacao = idEstacao;
        this.alturaOnda = alturaOnda;
        this.periodoOnda = periodoOnda;
        this.dataHora = dataHora;
    }
}
