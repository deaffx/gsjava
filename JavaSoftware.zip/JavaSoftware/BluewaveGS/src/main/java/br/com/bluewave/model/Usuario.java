package br.com.bluewave.model;

import java.util.Date;

public class Usuario {

    private int id;
    private String username;
    private String password; // Senha criptografada
    private String email;
    private Date createdAt;

    public Usuario() {}

    public Usuario(int id, String username, String password, String email, Date createdAt) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.createdAt = createdAt;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    // Método para validar se o email está no formato correto
    public boolean validarEmail() {
        return email != null && email.contains("@");
    }

    // Método para validar se a senha atende a um critério de segurança
    public boolean validarSenha() {
        return password != null && password.length() >= 8; // Exemplo: Senha com no mínimo 8 caracteres
    }
}
