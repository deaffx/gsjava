package br.com.bluewave.beans;

import java.sql.Timestamp;

public class ConsumoEnergia {
    private int id;
    private int idEstacao;
    private Timestamp dataHora;
    private double energiaUtilizada;

    // Construtor vazio
    public ConsumoEnergia() {}

    // Construtor completo
    public ConsumoEnergia(int id, int idEstacao, Timestamp dataHora, double energiaUtilizada) {
        this.id = id;
        this.idEstacao = idEstacao;
        this.dataHora = dataHora;
        this.energiaUtilizada = energiaUtilizada;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEstacao() {
        return idEstacao;
    }

    public void setIdEstacao(int idEstacao) {
        this.idEstacao = idEstacao;
    }

    public Timestamp getDataHora() {
        return dataHora;
    }

    public void setDataHora(Timestamp dataHora) {
        this.dataHora = dataHora;
    }

    public double getEnergiaUtilizada() {
        return energiaUtilizada;
    }

    public void setEnergiaUtilizada(double energiaUtilizada) {
        this.energiaUtilizada = energiaUtilizada;
    }
}
