package br.com.bluewave.main;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.bluewave.beans.ConsumoEnergia;
import br.com.bluewave.dao.ConsumoEnergiaDAO;


public class TesteSelecionar {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//Instanciar objetos 
		ConsumoEnergiaDAO dao = new ConsumoEnergiaDAO();
		
		List<ConsumoEnergia> listaConsumo = (ArrayList<ConsumoEnergia>) dao.listarTodos();
		if(listaConsumo != null) {
			// foreach 
			for( ConsumoEnergia consumo : listaConsumo) {
				System.out.println(consumo.getId() + " \n" + 
									consumo.getIdEstacao() + " \n" + 
						        	consumo.getEnergiaUtilizada() + "\n " + 
									consumo.getDataHora() + "\n ");
			}
		}

	}

}
