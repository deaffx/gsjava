package br.com.bluewave.dao;

import br.com.bluewave.conexoes.ConexaoFactory;
import br.com.bluewave.model.Usuario;

import java.sql.*;

public class UsuarioDAO {

    private Connection connection;

    public UsuarioDAO() throws SQLException, ClassNotFoundException {
        try {
            this.connection = new ConexaoFactory().conexao();
        } catch (SQLException e) {
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
            throw e; // Propaga a exceção para ser tratada adequadamente
        }
    }

    public boolean criarUsuario(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO USERS (USERNAME, PASSWORD, EMAIL) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, usuario.getUsername());
            stmt.setString(2, usuario.getPassword());  // Senha já deve estar criptografada
            stmt.setString(3, usuario.getEmail());
            stmt.executeUpdate();
            return true; // Retorna true se o usuário foi criado com sucesso
        } catch (SQLException e) {
            System.err.println("Erro ao criar usuário: " + e.getMessage());
            throw e; // Propaga a exceção
        }
    }

    public Usuario buscarUsuarioPorId(int id) throws SQLException {
        Usuario usuario = null;
        String sql = "SELECT * FROM USERS WHERE ID = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                usuario = new Usuario();
                usuario.setId(rs.getInt("ID"));
                usuario.setUsername(rs.getString("USERNAME"));
                usuario.setPassword(rs.getString("PASSWORD"));
                usuario.setEmail(rs.getString("EMAIL"));
                usuario.setCreatedAt(rs.getTimestamp("CREATED_AT"));
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar usuário por ID: " + e.getMessage());
            throw e; // Propaga a exceção
        }
        return usuario;
    }

    public boolean atualizar(Usuario usuario) throws SQLException {
        String sql = "UPDATE USERS SET USERNAME = ?, PASSWORD = ?, EMAIL = ? WHERE ID = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, usuario.getUsername());
            stmt.setString(2, usuario.getPassword());
            stmt.setString(3, usuario.getEmail());
            stmt.setInt(4, usuario.getId());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar usuário: " + e.getMessage());
            throw e; // Propaga a exceção
        }
    }

    public boolean deletar(int id) throws SQLException {
        String sql = "DELETE FROM USERS WHERE ID = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Erro ao deletar usuário: " + e.getMessage());
            throw e; // Propaga a exceção
        }
    }

    // Fechar a conexão quando não for mais necessária
    public void fecharConexao() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Erro ao fechar conexão: " + e.getMessage());
        }
    }
}
