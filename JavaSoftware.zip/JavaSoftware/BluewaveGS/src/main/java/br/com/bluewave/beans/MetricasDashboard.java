package br.com.bluewave.beans;

import java.sql.Timestamp;

public class MetricasDashboard {
    private int id;
    private int idEstacao;
    private double totalEnergiaGerada;
    private double totalEnergiaConsumida;
    private Timestamp ultimaAtualizacao;

    // Construtor vazio
    public MetricasDashboard() {}

    // Construtor completo
    public MetricasDashboard(int id, int idEstacao, double totalEnergiaGerada, double totalEnergiaConsumida, Timestamp ultimaAtualizacao) {
        this.id = id;
        this.idEstacao = idEstacao;
        this.totalEnergiaGerada = totalEnergiaGerada;
        this.totalEnergiaConsumida = totalEnergiaConsumida;
        this.ultimaAtualizacao = ultimaAtualizacao;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEstacao() {
        return idEstacao;
    }

    public void setIdEstacao(int idEstacao) {
        this.idEstacao = idEstacao;
    }

    public double getTotalEnergiaGerada() {
        return totalEnergiaGerada;
    }

    public void setTotalEnergiaGerada(double totalEnergiaGerada) {
        this.totalEnergiaGerada = totalEnergiaGerada;
    }

    public double getTotalEnergiaConsumida() {
        return totalEnergiaConsumida;
    }

    public void setTotalEnergiaConsumida(double totalEnergiaConsumida) {
        this.totalEnergiaConsumida = totalEnergiaConsumida;
    }

    public Timestamp getUltimaAtualizacao() {
        return ultimaAtualizacao;
    }

    public void setUltimaAtualizacao(Timestamp ultimaAtualizacao) {
        this.ultimaAtualizacao = ultimaAtualizacao;
    }
}
