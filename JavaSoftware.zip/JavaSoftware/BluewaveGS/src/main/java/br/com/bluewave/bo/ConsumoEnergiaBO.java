package br.com.bluewave.bo;

import br.com.bluewave.beans.ConsumoEnergia;
import br.com.bluewave.dao.ConsumoEnergiaDAO;
import java.sql.SQLException;
import java.util.List;

public class ConsumoEnergiaBO {

    private ConsumoEnergiaDAO consumoEnergiaDAO;

    public ConsumoEnergiaBO() {
        this.consumoEnergiaDAO = new ConsumoEnergiaDAO();
    }

    // Método para listar todos os consumos de energia
    public List<ConsumoEnergia> listarTodos() throws SQLException {
        // Aqui você pode aplicar regras de negócio, como validações ou processamento extra
        return consumoEnergiaDAO.listarTodos();
    }

    // Método para listar consumos de energia por estação
    public List<ConsumoEnergia> listarConsumoPorEstacao(int idEstacao) throws SQLException {
        // Exemplo de uma possível regra de negócio: Verificar se o ID da estação é válido antes de buscar
        if (idEstacao <= 0) {
            throw new IllegalArgumentException("ID da estação inválido");
        }
        return consumoEnergiaDAO.listarConsumoPorEstacao(idEstacao);
    }

    // Método para calcular o consumo médio por estação
    public double calcularConsumoMedioPorEstacao(int idEstacao) throws SQLException {
        List<ConsumoEnergia> consumos = listarConsumoPorEstacao(idEstacao);
        if (consumos.isEmpty()) {
            return 0.0; // Se não houver consumos, retorna 0
        }
        double total = consumos.stream().mapToDouble(ConsumoEnergia::getEnergiaUtilizada).sum();
        return total / consumos.size();
    }

    // Método para buscar consumo de energia por ID
    public ConsumoEnergia buscarPorId(int id) throws SQLException {
        // Aplicando lógica de negócio, por exemplo, validando o ID
        if (id <= 0) {
            throw new IllegalArgumentException("ID inválido");
        }
        return consumoEnergiaDAO.buscarPorId(id);
    }

    // Método para inserir um novo consumo de energia
    public void inserir(ConsumoEnergia consumo) throws SQLException {
        // Verificando se os dados necessários estão corretos antes de inserir
        if (consumo.getIdEstacao() <= 0 || consumo.getEnergiaUtilizada() <= 0) {
            throw new IllegalArgumentException("Dados inválidos para o consumo");
        }
        consumoEnergiaDAO.inserir(consumo);
    }

    // Método para atualizar um consumo de energia
    public boolean atualizar(ConsumoEnergia consumo) throws SQLException {
        // Validando os dados do consumo antes de atualizar
        if (consumo.getId() <= 0 || consumo.getEnergiaUtilizada() <= 0) {
            throw new IllegalArgumentException("Dados inválidos para atualização");
        }
        return consumoEnergiaDAO.atualizar(consumo);
    }

    // Método para deletar um consumo de energia por ID
    public boolean deletar(int id) throws SQLException {
        // Validando o ID antes de tentar deletar
        if (id <= 0) {
            throw new IllegalArgumentException("ID inválido para exclusão");
        }
        return consumoEnergiaDAO.deletar(id);
    }
}
