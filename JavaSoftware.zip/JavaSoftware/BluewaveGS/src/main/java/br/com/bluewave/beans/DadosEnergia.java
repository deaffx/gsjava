package br.com.bluewave.beans;

import java.sql.Timestamp;

public class DadosEnergia {
    private int id;
    private int idEstacao;
    private double energiaGerada;
    private Timestamp dataHora;

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEstacao() {
        return idEstacao;
    }

    public void setIdEstacao(int idEstacao) {
        this.idEstacao = idEstacao;
    }

    public double getEnergiaGerada() {
        return energiaGerada;
    }

    public void setEnergiaGerada(double energiaGerada) {
        this.energiaGerada = energiaGerada;
    }

    public Timestamp getDataHora() {
        return dataHora;
    }

    public void setDataHora(Timestamp dataHora) {
        this.dataHora = dataHora;
    }

    // Construtores
    public DadosEnergia() {}

    public DadosEnergia(int id, int idEstacao, double energiaGerada, Timestamp dataHora) {
        this.id = id;
        this.idEstacao = idEstacao;
        this.energiaGerada = energiaGerada;
        this.dataHora = dataHora;
    }
}
