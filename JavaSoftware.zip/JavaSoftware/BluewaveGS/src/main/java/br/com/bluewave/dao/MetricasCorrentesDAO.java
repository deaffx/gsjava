package br.com.bluewave.dao;

import br.com.bluewave.conexoes.ConexaoFactory;
import br.com.bluewave.model.MetricasCorrentes;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MetricasCorrentesDAO {

    private Connection connection;

    public MetricasCorrentesDAO() {
        try {
            this.connection = new ConexaoFactory().conexao();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<MetricasCorrentes> listarTodos() {
        List<MetricasCorrentes> metricas = new ArrayList<>();
        String sql = "SELECT * FROM METRICASCORRENTES";

        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                MetricasCorrentes metrica = new MetricasCorrentes();
                metrica.setId(rs.getInt("ID"));
                metrica.setStationId(rs.getInt("STATION_ID"));
                metrica.setTimestamp(rs.getTimestamp("TIMESTAMP"));
                metrica.setCurrentSpeed(rs.getDouble("CURRENT_SPEED"));
                metrica.setCurrentDirection(rs.getDouble("CURRENT_DIRECTION"));
                metricas.add(metrica);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return metricas;
    }

    public MetricasCorrentes buscarPorId(int id) {
        MetricasCorrentes metrica = null;
        String sql = "SELECT * FROM METRICASCORRENTES WHERE ID = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                metrica = new MetricasCorrentes();
                metrica.setId(rs.getInt("ID"));
                metrica.setStationId(rs.getInt("STATION_ID"));
                metrica.setTimestamp(rs.getTimestamp("TIMESTAMP"));
                metrica.setCurrentSpeed(rs.getDouble("CURRENT_SPEED"));
                metrica.setCurrentDirection(rs.getDouble("CURRENT_DIRECTION"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return metrica;
    }

    public boolean inserir(MetricasCorrentes metrica) {
        String sql = "INSERT INTO METRICASCORRENTES (STATION_ID, TIMESTAMP, CURRENT_SPEED, CURRENT_DIRECTION) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, metrica.getStationId());
            stmt.setTimestamp(2, new Timestamp(metrica.getTimestamp().getTime()));
            stmt.setDouble(3, metrica.getCurrentSpeed());
            stmt.setDouble(4, metrica.getCurrentDirection());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean atualizar(MetricasCorrentes metrica) {
        String sql = "UPDATE METRICASCORRENTES SET STATION_ID = ?, TIMESTAMP = ?, CURRENT_SPEED = ?, CURRENT_DIRECTION = ? WHERE ID = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, metrica.getStationId());
            stmt.setTimestamp(2, new Timestamp(metrica.getTimestamp().getTime()));
            stmt.setDouble(3, metrica.getCurrentSpeed());
            stmt.setDouble(4, metrica.getCurrentDirection());
            stmt.setInt(5, metrica.getId());
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deletar(int id) {
        String sql = "DELETE FROM METRICASCORRENTES WHERE ID = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
