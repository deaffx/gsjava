package br.com.bluewave.beans;

import java.util.Date;

public class PrevisaoEnergia {
    private int id;
    private int idEstacao;
    private Date dataPrevisao;
    private double energiaPrevista;

    // Construtor vazio
    public PrevisaoEnergia() {}

    // Construtor completo
    public PrevisaoEnergia(int id, int idEstacao, Date dataPrevisao, double energiaPrevista) {
        this.id = id;
        this.idEstacao = idEstacao;
        this.dataPrevisao = dataPrevisao;
        this.energiaPrevista = energiaPrevista;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEstacao() {
        return idEstacao;
    }

    public void setIdEstacao(int idEstacao) {
        this.idEstacao = idEstacao;
    }

    public Date getDataPrevisao() {
        return dataPrevisao;
    }

    public void setDataPrevisao(Date dataPrevisao) {
        this.dataPrevisao = dataPrevisao;
    }

    public double getEnergiaPrevista() {
        return energiaPrevista;
    }

    public void setEnergiaPrevista(double energiaPrevista) {
        this.energiaPrevista = energiaPrevista;
    }
}
