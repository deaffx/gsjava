package br.com.bluewave.beans;

import java.sql.Timestamp;

public class Alertas {
    private int id;
    private int idEstacao;
    private String mensagem;
    private Timestamp dataAlerta;

    // Construtor vazio
    public Alertas() {}

    // Construtor completo
    public Alertas(int id, int idEstacao, String mensagem, Timestamp dataAlerta) {
        this.id = id;
        this.idEstacao = idEstacao;
        this.mensagem = mensagem;
        this.dataAlerta = dataAlerta;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEstacao() {
        return idEstacao;
    }

    public void setIdEstacao(int idEstacao) {
        this.idEstacao = idEstacao;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public Timestamp getDataAlerta() {
        return dataAlerta;
    }

    public void setDataAlerta(Timestamp dataAlerta) {
        this.dataAlerta = dataAlerta;
    }
}
