package br.com.bluewave.beans;

import java.sql.Timestamp;

public class MetricasCorrentes {
    private int id;
    private int idEstacao;
    private Timestamp dataHora;
    private double velocidadeCorrente;
    private double direcaoCorrente;

    // Construtor vazio
    public MetricasCorrentes() {}

    // Construtor completo
    public MetricasCorrentes(int id, int idEstacao, Timestamp dataHora, double velocidadeCorrente, double direcaoCorrente) {
        this.id = id;
        this.idEstacao = idEstacao;
        this.dataHora = dataHora;
        this.velocidadeCorrente = velocidadeCorrente;
        this.direcaoCorrente = direcaoCorrente;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEstacao() {
        return idEstacao;
    }

    public void setIdEstacao(int idEstacao) {
        this.idEstacao = idEstacao;
    }

    public Timestamp getDataHora() {
        return dataHora;
    }

    public void setDataHora(Timestamp dataHora) {
        this.dataHora = dataHora;
    }

    public double getVelocidadeCorrente() {
        return velocidadeCorrente;
    }

    public void setVelocidadeCorrente(double velocidadeCorrente) {
        this.velocidadeCorrente = velocidadeCorrente;
    }

    public double getDirecaoCorrente() {
        return direcaoCorrente;
    }

    public void setDirecaoCorrente(double direcaoCorrente) {
        this.direcaoCorrente = direcaoCorrente;
    }
}
