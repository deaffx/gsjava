package br.com.bluewave.resource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.bluewave.beans.ConsumoEnergia;
import br.com.bluewave.bo.ConsumoEnergiaBO;

@Path("/consumoenergia")
public class ConsumoEnergiaResource {

    private ConsumoEnergiaBO consumoBO = new ConsumoEnergiaBO();

    // Método GET para listar todos os consumos de energia
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response listarTodos() {
        try {
            List<ConsumoEnergia> consumos = consumoBO.listarTodos();
            return Response.ok(consumos).build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }

    // Método GET para buscar consumo de energia por ID
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response buscarPorId(@PathParam("id") int id) {
        try {
            ConsumoEnergia consumo = consumoBO.buscarPorId(id);
            if (consumo != null) {
                return Response.ok(consumo).build();
            } else {
                return Response.status(Response.Status.NOT_FOUND).entity("Consumo de Energia não encontrado.").build();
            }
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }

    // Método POST para criar um novo consumo de energia
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response criar(ConsumoEnergia consumo) {
        try {
            consumoBO.inserir(consumo);
            return Response.status(Response.Status.CREATED).entity(consumo).build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }

    // Método PUT para atualizar o consumo de energia
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response atualizar(@PathParam("id") int id, ConsumoEnergia consumo) {
        try {
            consumo.setId(id);
            if (consumoBO.atualizar(consumo)) {
                return Response.ok(consumo).build();
            } else {
                return Response.status(Response.Status.NOT_FOUND).entity("Consumo de Energia não encontrado.").build();
            }
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }

    // Método DELETE para deletar o consumo de energia por ID
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.TEXT_PLAIN)
    public Response deletar(@PathParam("id") int id) {
        try {
            if (consumoBO.deletar(id)) {
                return Response.ok("Consumo de Energia deletado com sucesso.").build();
            } else {
                return Response.status(Response.Status.NOT_FOUND).entity("Consumo de Energia não encontrado.").build();
            }
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }
}
