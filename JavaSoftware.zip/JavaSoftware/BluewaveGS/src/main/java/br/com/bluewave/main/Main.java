package br.com.bluewave.main;

import br.com.bluewave.resource.*;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;

import javax.ws.rs.ApplicationPath;

@ApplicationPath("/api")
public class Main extends ResourceConfig {
    public Main() {
        // Registro de todos os recursos REST
        register(CorsFilter.class); 
        register(ConsumoEnergiaResource.class);
        register(MetricasCorrentesResource.class);
        
    }

    public static void main(String[] args) {
        
        int port = 8080;

        
        if (args.length > 0) {
            try {
                port = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                System.err.println("Porta inválida, utilizando porta padrão 8080.");
            }
        }

        Server server = new Server(port);

        ServletContainer servletContainer = new ServletContainer(new Main());
        ServletHolder servletHolder = new ServletHolder(servletContainer);

        ServletContextHandler contextHandler = new ServletContextHandler(ServletContextHandler.NO_SESSIONS);
        contextHandler.setContextPath("/api");
        contextHandler.addServlet(servletHolder, "/*");

        server.setHandler(contextHandler);

        try {
            System.out.println("Servidor iniciado na porta " + port);
            server.start();
            server.join();
        } catch (Exception e) {
            System.err.println("Erro ao iniciar o servidor: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                server.stop();
                System.out.println("Servidor parado.");
            } catch (Exception e) {
                System.err.println("Erro ao parar o servidor: " + e.getMessage());
            }
        }
    }
}
