package br.com.bluewave.model;

import java.util.Date;

public class ConsumoEnergia {

    private int id;
    private int stationId;
    private Date timestamp;
    private double energyUsed;

    public ConsumoEnergia() {}

    public ConsumoEnergia(int id, int stationId, Date timestamp, double energyUsed) {
        this.id = id;
        this.stationId = stationId;
        this.timestamp = timestamp;
        this.energyUsed = energyUsed;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStationId() {
        return stationId;
    }

    public void setStationId(int stationId) {
        this.stationId = stationId;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public double getEnergyUsed() {
        return energyUsed;
    }

    public void setEnergyUsed(double energyUsed) {
        this.energyUsed = energyUsed;
    }
}
