package br.com.bluewave.services;

import br.com.bluewave.bo.ConsumoEnergiaBO; // Alterar para importar o BO
import br.com.bluewave.beans.ConsumoEnergia;

import java.sql.SQLException;
import java.util.List;

public class ConsumoEnergiaService {

    private ConsumoEnergiaBO consumoEnergiaBO; // Alterar para usar o BO

    public ConsumoEnergiaService() {
        this.consumoEnergiaBO = new ConsumoEnergiaBO(); // Inicializa o BO
    }

    public double calcularConsumoMedioPorEstacao(int idEstacao) throws SQLException {
        // Chama o método do BO em vez de chamar o DAO diretamente
        List<ConsumoEnergia> consumos = consumoEnergiaBO.listarConsumoPorEstacao(idEstacao);
        double total = consumos.stream().mapToDouble(ConsumoEnergia::getEnergiaUtilizada).sum();
        return consumos.size() > 0 ? total / consumos.size() : 0.0;
    }
}
