package br.com.bluewave.resource;

import br.com.bluewave.dao.MetricasCorrentesDAO;
import br.com.bluewave.model.MetricasCorrentes;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.util.List;

@Path("/metricascorrentes")
public class MetricasCorrentesResource {

    private MetricasCorrentesDAO dao = new MetricasCorrentesDAO();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response listarTodos() {
        try {
            List<MetricasCorrentes> metricas = dao.listarTodos();
            return Response.ok(metricas).build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response buscarPorId(@PathParam("id") int id) {
        try {
            MetricasCorrentes metrica = dao.buscarPorId(id);
            if (metrica != null) {
                return Response.ok(metrica).build();
            } else {
                return Response.status(Response.Status.NOT_FOUND).entity("Métrica de Corrente não encontrada.").build();
            }
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response criar(MetricasCorrentes metrica) {
        try {
            dao.inserir(metrica);
            return Response.status(Response.Status.CREATED).entity(metrica).build();
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }

    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response atualizar(@PathParam("id") int id, MetricasCorrentes metrica) {
        try {
            metrica.setId(id);
            if (dao.atualizar(metrica)) {
                return Response.ok(metrica).build();
            } else {
                return Response.status(Response.Status.NOT_FOUND).entity("Métrica de Corrente não encontrada.").build();
            }
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }

    @DELETE
    @Path("/{id}")
    @Produces(MediaType.TEXT_PLAIN)
    public Response deletar(@PathParam("id") int id) {
        try {
            if (dao.deletar(id)) {
                return Response.ok("Métrica de Corrente deletada com sucesso.").build();
            } else {
                return Response.status(Response.Status.NOT_FOUND).entity("Métrica de Corrente não encontrada.").build();
            }
        } catch (Exception e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(e.getMessage()).build();
        }
    }
}
