package br.com.bluewave.main;

import java.sql.Connection;
import java.sql.SQLException;

import br.com.bluewave.conexoes.ConexaoFactory;

public class TesteConexao {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Connection cn = new ConexaoFactory().conexao();
		System.out.println("Conectado");
		cn.close();
	}

}
