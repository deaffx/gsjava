package br.com.bluewave.model;

import java.util.Date;

public class MetricasCorrentes {

    private int id;
    private int stationId;
    private Date timestamp;
    private double currentSpeed;
    private double currentDirection;

    public MetricasCorrentes() {}

    public MetricasCorrentes(int id, int stationId, Date timestamp, double currentSpeed, double currentDirection) {
        this.id = id;
        this.stationId = stationId;
        this.timestamp = timestamp;
        this.currentSpeed = currentSpeed;
        this.currentDirection = currentDirection;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getStationId() {
        return stationId;
    }

    public void setStationId(int stationId) {
        this.stationId = stationId;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public double getCurrentSpeed() {
        return currentSpeed;
    }

    public void setCurrentSpeed(double currentSpeed) {
        this.currentSpeed = currentSpeed;
    }

    public double getCurrentDirection() {
        return currentDirection;
    }

    public void setCurrentDirection(double currentDirection) {
        this.currentDirection = currentDirection;
    }
}
