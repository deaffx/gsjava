package br.com.bluewave.dao;

import br.com.bluewave.beans.ConsumoEnergia;
import br.com.bluewave.conexoes.ConexaoFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ConsumoEnergiaDAO {

    private Connection minhaConexao;

    public ConsumoEnergiaDAO() {
        try {
            this.minhaConexao = new ConexaoFactory().conexao();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método para listar todos os consumos de energia
    public List<ConsumoEnergia> listarTodos() throws SQLException {
        List<ConsumoEnergia> consumos = new ArrayList<>();
        try (Statement stmt = minhaConexao.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM ConsumoEnergia")) {

            while (rs.next()) {
                ConsumoEnergia consumo = new ConsumoEnergia();
                consumo.setId(rs.getInt("id"));
                consumo.setIdEstacao(rs.getInt("id_estacao"));
                consumo.setDataHora(rs.getTimestamp("data_hora"));
                consumo.setEnergiaUtilizada(rs.getDouble("energia_utilizada"));
                consumos.add(consumo);
            }
        }
        return consumos;
    }

    // Método para listar consumos de energia por estação
    public List<ConsumoEnergia> listarConsumoPorEstacao(int idEstacao) throws SQLException {
        List<ConsumoEnergia> consumos = new ArrayList<>();
        String sql = "SELECT * FROM ConsumoEnergia WHERE id_estacao = ?";
        
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setInt(1, idEstacao);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                ConsumoEnergia consumo = new ConsumoEnergia();
                consumo.setId(rs.getInt("id"));
                consumo.setIdEstacao(rs.getInt("id_estacao"));
                consumo.setDataHora(rs.getTimestamp("data_hora"));
                consumo.setEnergiaUtilizada(rs.getDouble("energia_utilizada"));
                consumos.add(consumo);
            }
        }
        return consumos;
    }

    // Método para buscar consumo de energia por ID
    public ConsumoEnergia buscarPorId(int id) throws SQLException {
        String sql = "SELECT * FROM ConsumoEnergia WHERE id = ?";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                ConsumoEnergia consumo = new ConsumoEnergia();
                consumo.setId(rs.getInt("id"));
                consumo.setIdEstacao(rs.getInt("id_estacao"));
                consumo.setDataHora(rs.getTimestamp("data_hora"));
                consumo.setEnergiaUtilizada(rs.getDouble("energia_utilizada"));
                return consumo;
            }
        }
        return null; // Se não encontrar o consumo
    }

    // Método para inserir um novo consumo de energia
    public void inserir(ConsumoEnergia consumo) throws SQLException {
        String sql = "INSERT INTO ConsumoEnergia (id_estacao, data_hora, energia_utilizada) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = minhaConexao.prepareStatement(sql)) {
            stmt.setInt(1, consumo.getIdEstacao());
            stmt.setTimestamp(2, consumo.getDataHora());
            stmt.setDouble(3, consumo.getEnergiaUtilizada());
            stmt.executeUpdate();
        }
    }

    // Método para atualizar um consumo de energia
    public boolean atualizar(ConsumoEnergia consumo) throws SQLException {
        
        try (PreparedStatement stmt = minhaConexao.prepareStatement("UPDATE ConsumoEnergia SET id_estacao = ?, data_hora = ?, energia_utilizada = ? WHERE id = ?")) {
            stmt.setInt(1, consumo.getIdEstacao());
            stmt.setTimestamp(2, consumo.getDataHora());
            stmt.setDouble(3, consumo.getEnergiaUtilizada());
            stmt.setInt(4, consumo.getId());
            int rowsUpdated = stmt.executeUpdate();
            return rowsUpdated > 0; // Retorna true se algum registro foi atualizado
        }
    }

    // Método para deletar um consumo de energia por ID
    public boolean deletar(int id) throws SQLException {
        try (PreparedStatement stmt = minhaConexao.prepareStatement("DELETE FROM ConsumoEnergia WHERE id = ?")) {
            stmt.setInt(1, id);
            int rowsDeleted = stmt.executeUpdate();
            return rowsDeleted > 0; // Retorna true se algum registro foi deletado
        }
    }
}
